export const bodyColor = "#39496A";
export const mutedColor = "#6D727C";
export const linkColor = "#1C7CD6";
export const codePrimaryColor = "#657B83";
export const codeSecondaryColor = "#6078A9";
